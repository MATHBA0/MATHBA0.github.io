function FindTheLaurentPolyOf(B,R,Z,Mutation,Permutation,eta,d)

%% ------------- 准备工作，调整下标
%因为实际下标从0开始，而matlab从1开始。
n = size(B,1);
fix = ones(1,n);
eta_fix = eta + fix;

%% ------------- 制作集合N，每行是一个指标。
N = zeros(prod(eta_fix), n);
for i = 2:1:size(N,1)
    N(i,:) = N(i-1,:);
    N(i,n) = N(i,n)+1;
    for j = n:-1:2
        if N(i,j) > eta(j)
            N(i,j) = 0;
            N(i,j-1) = N(i,j-1) + 1;
        end
    end
end

%% ------------- 构造线性方程组的矩阵A

if isa(Z,'sym')
    A = sym('A', [1,prod(eta_fix)]);
else
    A = zeros(1,prod(eta_fix));
end
A(1,1:end) = 0; 
eqnNum = 1;

for t = 1:1:size(Mutation,1)
    s = Mutation(t,1);
    sigma = Permutation(t,:);

    %% ------------- 计算sigma的逆。
    iSigma = 1:n;
    for i=1:n-1
        iSigma = sigma(iSigma);
    end

    %% ------------- 制作集合 sigma^{-1}(N)
    iSig_N = N(:, iSigma);

    for k = 0:1:d(s)
        %% ------------- 制作集合 Cup N+B，Cup sigma^{-1}(N)+B.
        N_B = N + vec(B,R,s,k,0,2*k);
        iSig_N_B = iSig_N + vec(B,R,s,k,0,2*k);

        for l = 1:1:k*R(s) 
            N_B = union(N_B, N + vec(B,R,s,k,l,2*k), 'rows');
            iSig_N_B = union(iSig_N_B, iSig_N + vec(B,R,s,k,l,2*k), 'rows');
        end

        %% ------------- (A1) 0 = a_{sigam(j)} - sum a_{j-B}
        set = intersect(iSig_N, N_B, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);
        for j = 1:1:size(pi_set,1)
            bf_j = pi_set(j,:);
            % 1.构造 Sum a_{j-B}
            for l = 0:1:k*R(s)
                if ismember(bf_j - vec(B,R,s,k,l,2*k), N, 'rows') 
                    index = ismember(N, bf_j - vec(B,R,s,k,l,2*k), 'rows');
                    A(eqnNum, index) = A(eqnNum, index) + coeff(R,Z,s,k,l);        
                end
            end
            % 2.构造 a_{sigma(j)}
            index = ismember(N, bf_j(sigma), 'rows');
            A(eqnNum, index) = A(eqnNum, index)-1;
            % 3.一个方程已经构造完成
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        %% 时刻用Gauss消元法化简A，避免矩阵A过大。
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;

        %% ------------- (A2) sum a_{j-B} = 0
        set = setdiff(N_B,iSig_N, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);
        for j = 1:1:size(pi_set,1)
            bf_j = pi_set(j,:);
            % 1.构造 Sum a_{j-B}
            for l = 0:1:k*R(s)
                if ismember(bf_j - vec(B,R,s,k,l,2*k), N, 'rows') 
                    index = ismember(N, bf_j - vec(B,R,s,k,l,2*k), 'rows');
                    A(eqnNum, index) = A(eqnNum, index)+coeff(R, Z ,s,k,l);
                end
            end
            % 一个方程已经构造完成
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        %% 时刻用Gauss消元法化简A，避免矩阵A过大。
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;

        %% ------------- (A3) a_sig_j = 0
        set = setdiff(iSig_N,N_B, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);

        for j = 1:1:size(pi_set,1)

            bf_j = pi_set(j,:);

            % 2.构造 a_{sigma(j)}
            index = ismember(N, bf_j(1,sigma), 'rows');
            A(eqnNum, index) = A(eqnNum, index) - 1;
            % 一个方程已经构造完成
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end

        %% ------------- (C1) 0 = a_{j} - sum a_{sigma(j-B)}
        set = intersect(N, iSig_N_B, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);
        for j = 1:1:size(pi_set,1)
            bf_j = pi_set(j,:);
            % 1.构造 Sum a_{j-B}
            for l = 0:1:k*R(s)
                bf_j_vec = bf_j - vec(B,R,s,k,l,2*k);
                bf_j_vec = bf_j_vec(sigma);
                if ismember(bf_j_vec, N, 'rows')
                    index = ismember(N, bf_j_vec, 'rows');
                    A(eqnNum, index) = A(eqnNum, index) + coeff(R,Z,s,k,l);
                end
            end
            % 2.构造 a_{j}
            index = ismember(N, bf_j, 'rows');
            A(eqnNum, index) = A(eqnNum, index) - 1;
            % 3.一个方程已经构造完成
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        %% 时刻用Gauss消元法化简A，避免矩阵A过大。
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;
        
        %% ------------- (C2) 0 = sum a_{sigma(j-B)}
        set = setdiff(iSig_N_B, N, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);
        for j = 1:1:size(pi_set,1)
            bf_j = pi_set(j,:);
            % 1.构造 Sum a_{j-B}
            for l = 0:1:k*R(s)
                bf_j_vec = bf_j - vec(B,R,s,k,l,2*k);
                bf_j_vec = bf_j_vec(sigma);
                if ismember(bf_j_vec, N, 'rows')
                    index = ismember(N, bf_j_vec, 'rows');
                    A(eqnNum, index) = A(eqnNum, index) + coeff(R,Z,s,k,l);
                end
            end
            % 3.一个方程已经构造完成
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        %% 时刻用Gauss消元法化简A，避免矩阵A过大。
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;

        %% ------------- (C3) 0 = a_{j}
        set = setdiff(N, iSig_N_B, 'rows');
        pi_set = set(set(:,s)==d(s)-k,:);

        for j = 1:1:size(pi_set,1)

            bf_j = pi_set(j,:);

            % 2.构造 a_{j}
            index = ismember(N, bf_j, 'rows');
            A(eqnNum, index) = A(eqnNum, index) - 1;

            % 3.一个方程已经构造完成
            eqnNum = eqnNum + 1;
            A(eqnNum, 1) = 0;
        end
        %% 时刻用Gauss消元法化简A，避免矩阵A过大。
        A = rref(A);
        eqnNum = size(A,1)+1;
        A(eqnNum, 1) = 0;
    end

    %% 时刻用Gauss消元法化简A，避免矩阵A过大。
    A = rref(A);
    eqnNum = size(A,1)+1;
    A(eqnNum, 1) = 0;
end

%% ------------- 解齐次线性方程组A
if isa(Z,'sym')
    sol = null(A);
else
    sol = null(A, 'r');
end
[row, col, val] = find(sol);
%% ---------- 不输出平凡项 
% num = 0;
% class = 0;
% row_fix = 0;
% col_fix = 0;
% val_fix = sym('val_', [0,0]);
% for j = 1:1:max(col)
%     sameclass = find(col==j); 
%     if size(sameclass,1) ~= 1 % delete monomial
%         class = class + 1;
%         for i=1:1:size(sameclass,1)
%             num = num+1;
%             row_fix(num,1) = row(sameclass(i));
%             col_fix(num,1) = col(sameclass(i));
%             val_fix(num,1) = val(sameclass(i));
%         end
%     end
% end
%% ---------- 输出平凡项
row_fix = row;
col_fix = col;
val_fix = val;

%% ---------- 打印结果
disp('=======================================================');
disp('The solution is');
blank = '   ';
for b=1:1:n-4
    blank = [blank, '   '];
end 
disp(['  Class  Coefficent  Subscript  ', blank ,'Monomial'])
class = 0;
for j = 1:1:size(col_fix,1)  
    if j > 1
        if col_fix(j-1)~=col_fix(j)
            class = class + 1;
        end
    elseif j == 1
        class = class + 1;
    end

    multiple = val_fix(j);
    subscript =  N(row_fix(j),:);
    monomial = [];
    for t = 1:1:n
        if subscript(t)~=0
            if subscript(t) == 1
                monomial = [monomial, ['x_',num2str(t)]];
            else
                monomial = [monomial, ['x_',num2str(t),'^',num2str(subscript(t))]];
            end
        end
    end
    disp(['    ', num2str(class), '       ',sym2str(multiple),'       ',num2str(subscript),'    ', monomial] );
end

%% ----------- 整理计算结果
disp(' ');
disp('Hence we have');
x = sym('x_', [1,n]);
uniCol = unique(col_fix);

s_f = x(1);
s_f(1) = [];
for j = 1:1:class
    [index, ~] = find(col_fix == uniCol(j));
    for i = 1:1:size(index,1)
        mono = val_fix(index(i)).*prod(x.^N(row_fix(index(i)),:));
        if i == 1
            f = mono;
        else
            f = f + mono;
        end
    end
    
    s_f(j) = simplify(f);
    fprintf('  The polynomial of Class %d is:\n       %s\n',j, s_f(j));
    
    %sym2latex(s_f);
end
disp('=======================================================');
end

% %% 展示LaTeX
% 
% colum_add = 1 + n+ 1 + n + 2+1+1;
% 
% poly = strings(class*2 + colum_add,1);
% 
% poly(1, 1) = ['The exchange matrix $B$ is'];
% poly(2:n+1, 1) = num2str(B);
% poly(n+2, 1) = ['$R = diag($', num2str(R),'$)$'];
% 
% % show_Z = zeros(size(Z,1),size(Z,2)+2);
% % show_Z(:,1) = 1;
% % show_Z(:,end) = 1;
% % show_Z(:,2:end-1) = Z;
% % syms u;
% % 
% % for j = 1:1:size(Z,1)
% %     ZZ = u.^[0:size(show_Z,2)-1]*(show_Z(j,:))';
% %     poly(n+2+j, 1) = ['$Z_{',num2str(j),'}(u) = ', latex(ZZ),'$'];
% % end
% 
% 
% syms u;
% 
% for j = 1:1:size(Z,1)
%     ZZ = u.^[0:size(Z,2)-1]*(Z(j,:))';
%     poly(n+2+j, 1) = ['$Z_{',num2str(j),'}(u) = ', latex(ZZ),'$'];
% end
% 
% poly(n+2+n+1, 1) = ['$$\eta = (', num2str(eta) ,')$$'];
% poly(n+2+n+2, 1) = ['$$d = (', num2str(d) ,')$$'];
% 
% poly(colum_add-1, 1) = '';
% poly(colum_add, 1) = ['---------------ANS---------------'];
% 
% for j = 1:1:class
% 	poly(2*j-1+ colum_add, 1) = ['The polynomial of Class ', num2str(j),' is'];
% 	poly(2*j + colum_add, 1) =   ['   ', '$$', latex(s_f(j)),'$$'];
% 
% end
% sym2latex(poly);
