function M = FindTheClusterSymPairOf(T, d, x)
n = size(x,2);                    %变量个数
Perm_n = perms(1:n);              %构造置换群S_n
[~, invPerm_n] = sort(Perm_n, 2); %对应置换的逆元

%% --------STEP 1 构造集合 M
M = cell(0,6);      % is a set of cluster sym pairs
num = 0;            % is #M

%% --------STEP 2 求\deg^i T
eta = zeros(1,n);
for i = 1:1:n
   eta(1,i) = polynomialDegree(T, x(i));
end    

%% --------STEP 3 构造非平凡的方向集合S
S = setdiff(find(mod(eta,2)==0), find(eta==0));

%% --------STEP 4 遍历每个方向
for s = S
    %% --------STEP 5 构造方向s潜在的置换集合 \Sigma_s
    Sigma_s = zeros(size(Perm_n));
    numSigma_s = 0;
    for sigma_index = 1:1:size(Perm_n,1)
        sigma = Perm_n(sigma_index,:);
        invsigma = invPerm_n(sigma_index,:);
        if and(ismember(invsigma(s),S), eta(1,s)==eta(1,invsigma(s)))
            numSigma_s = numSigma_s+1;
            Sigma_s(numSigma_s, :) = sigma;
        end
    end
    
    %% --------STEP 6 遍历\Sigma_s中的每个置换
    for sigma_index = 1:1:numSigma_s
        %% --------STEP 7 计算 t = \sigma^{-1}(s)
        sigma = Sigma_s(sigma_index,:);
        [~, invsigma] = sort(sigma, 2);
        t = invsigma(s);
        %% --------STEP 8 构造 \tilde{d} s.t.
        % \sigma(d+\tilde{d}) = d+\tilde{d}, 2(d_s + \tilde{d}_s) = \eta_s
        tilde_d = sym('td_', [1,n]);
        tilde_d(1,s) = eta(1,s)/2 - d(1,s);
        check =  zeros(1,n);
        pre_s = s;
        check(pre_s) = 1;
        while sigma(pre_s) ~= s
            pre_s = sigma(pre_s);
            tilde_d(1, pre_s) = eta(1,s)/2 - d(1,pre_s);
            check(pre_s) = 1;
        end
        for i=1:1:n
            if check(i) == 0
                pre_i = i;
                check(pre_i) = 1;
                tilde_d(1, i) = tilde_d(1, i) - d(1,i);
                while sigma(pre_i) ~= i
                    pre_i = sigma(pre_i);
                    tilde_d(1, pre_i) = tilde_d(1, i) + d(1,i) - d(1,pre_i);
                    check(pre_i) = 1;
                end
            end
        end
        %% --------STEP 9~10 构造多项式 f_{s,i} 与 f_{t,i}
        fs = coeffs(T, x(s), 'all'); %降幂排序
        ft = coeffs(T, x(t), 'all');
        %% --------STEP 11
        K1 = find(fs==0) - 1;
        K2 = eta(s) + 1 - find(ft==0);
        if isequal(sort(K1), sort(K2))
            %% --------STEP 12~14
            K = setdiff([0:eta(1,s)], K1); 
            card = 0;
            k0 = max(K(K < eta(1,s)/2));
            %% --------STEP 15~16 判定P(x)的存在性。
            subsft = subs(ft(eta(1,s)-k0+1), x, x(sigma));
            if gcd(subsft, fs(k0+1)) == fs(k0+1)
                Pdk = simplify(subsft/fs(k0+1));
                preP = factor(Pdk, x);
                constant = unique(subs(preP, x, zeros(1,n)));
                constant(constant==0) = 1; %when multiple be 1
                constant = prod(constant);
                P = constant.^(eta(1,s)/2-k0);
                nonconstant = preP(preP ~= constant);
                fact = unique(nonconstant);
                if ~isempty(fact)
                    for j=1:1:size(fact, 2)
                       power_fact = size(find(nonconstant == fact(j)),2);
                       if mod(power_fact, eta(1,s)/2-k0)==0
                           P = P*fact(j).^(power_fact/(eta(1,s)/2-k0));
                       else
                           P = 0;
                           break
                       end
                    end
                end
                if P~=0
                    card = card+1;
                    %% --------STEP 17~19 
                    for k = setdiff(K, k0)
                        if simplify(subs(ft(eta(1,s)-k+1), x, x(sigma))) == simplify(fs(k+1)*P.^(eta(1,s)/2-k))
                            card = card + 1;
                        else
                            break
                        end
                    end
                    if card == size(K,2)
                       %% --------STEP 20~23 判断Z(u)的存在性
                       [Pcoeff, Pitem] = coeffs(P,x);
                       B = zeros(size(Pitem,2),n);
                       for j = 1:1:size(B,1)
                           for l = 1:1:n
                               B(j,l) = polynomialDegree(Pitem(j),x(l));
                           end
                       end
                       Bminus = B - B(1,:);
                       if rank(Bminus) == 1 
                          Breduce = rref(Bminus);                         
                          preb = Breduce(1,:);
                          high = 0;
                          low  = 0;
                          maxpower  = 0;
                          for j=1:1:size(B,1)
                              for l = 1:1:size(B,1)
                                  findb = B(j,:)-B(l,:);
                                  prer = unique(findb./preb);
                                  r = prer(1);
                                  if r > maxpower
                                      maxpower  = r;
                                      high  = j;
                                      low = l;
                                  end
                              end
                          end
                          if high ~=0
                              powerofB = zeros(1,size(B,1));
                              for j=1:1:size(B,1)
                                  if j==low
                                     powerofB(j) = 0;
                                  else
                                     powerofB(j) = unique(nonzeros(B(j,:)-B(low,:))./nonzeros(preb));
                                  end
                              end
                              [acA, acB] = sort(powerofB,'ascend');
                              [dcA, dcB] = sort(powerofB,'descend');
                              % bulid r and b
                              R = union(factor(maxpower),[1,maxpower]);
                              minpower = size(Pitem,2)-1;
                              R = R(R>=minpower);
                              R = setdiff(R,0); % Assume r ~= 0
                              syms u;
                              for r = R
                                  Z = 0;
                                  multi = maxpower./r;
                                  b = preb.*multi;
                                  for j=0:1:(max(dcA)-min(dcA))/multi
                                      if ismember(j*multi,dcA)
                                          l = find(dcA==j*multi);
                                          Z = Z+Pcoeff(dcB(l))*u^j;
                                      end
                                  end 
                                  num = num+1;
                                  %% --------STEP 24
                                  M(num,:) = {s sigma b r sym2str(Z) tilde_d};
                                  num = num+1;
                                  invZ = simplify(u^r*subs(Z,u,1/u));
                                  M(num,:) = {s sigma -b r sym2str(invZ) tilde_d};
                              end                       
                          end
                       end
                    end
                end
            end
        end
    end
end  
%% ------------- 打印结果
disp('===========================================');
disp(['T(x) = ', sym2str(T)])
disp(['  d  = ', mat2str(d)])
disp(' ')
disp('The nontrivial 1-cluster symmetric pairs of T(x)x^{-d} are ')
disp(cell2table(M, "VariableNames", ["s" "sigma" "b" "r" "Z" "tilde{d}"]))
disp('===========================================');
end