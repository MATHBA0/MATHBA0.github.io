function C = coeff(R,Z,s,k,l)
% 构造系数 c_{k,l}
    C = 0;
    if k==0
        C = 1;
    elseif k>0
        %% the combinations of index 
        N = zeros((R(s)+1)^k, k);
        for t = 2:1:size(N,1)
            N(t,:) = N(t-1,:);
            N(t,k) = N(t,k)+1;
            for q = k:-1:2
                if N(t,q) > R(s)
                    N(t,q) = 0;
                    N(t,q-1) = N(t,q-1) + 1;
                end
            end
        end
        
        %% find l_1,...,l_j such that, l_1+...+l_j = l.
        index = N(sum(N,2)==l,:); 
        for u=1:1:size(index,1)
            sumz = 1;
            for v = 1:1:k
                sumz = sumz*Z(s, index(u,v)+1);
            end
            C = C + sumz;
        end
    end
end