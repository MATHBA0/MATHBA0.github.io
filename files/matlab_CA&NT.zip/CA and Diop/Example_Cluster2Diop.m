example = 4.22;

% NOTE: when class(Z) is 'sym', the program will much slow.

switch example
    case 0
        times = 1;
        gcd = 1;
        B = zeros(3);
        R = ones(1,3).*gcd;
        Z = ones([size(R,2), max(R)+1]);

%         Mutation = repelem([1;2;3],6);
%         PP = perms([1:3]);
%         Permutation = [PP;PP;PP];
       
        Mutation = repelem([1;2;3],1);
%         PP = perms([1:3]);
        Permutation = [1:3;1:3;1:3];
        eta = [2,2,2].*times;
        d = [1,1,1].*times;
    case 3 % B_3^1
        times = 1;
        gcd = 1;
        B = [0,-1,-1;
             1, 0,-1;
             1, 1, 0]./gcd;
        R = ones(1,3).*gcd;
        Z = ones([size(R,2), max(R)+1]);
        Mutation = [1];
        Permutation = [2,3,1];
        eta = [2,3,2].*times;
        d = [1,1,1].*times;
    case 3.1 % Markov
        times = 1; 
        gcd = 1;
        B = [0, 2,-2;
            -2, 0, 2;
             2,-2, 0]./gcd;
        R = ones(1,3).*gcd;
        Z = ones([size(R,2), max(R)+1]);

        Mutation = [1;2;3];
        Permutation = [1:3;1:3;1:3];
        eta = [2,2,2];
        d = [1,1,1];

    case 3.19 % Markov
        times = 1; 
        gcd = 1;
        B = [0, 2, 0;
            -2, 0, 0;
             0, 0, 0]./gcd;
        R = ones(1,3).*gcd;
        Z = ones([size(R,2), max(R)+1]);
        Mutation = [1;2;3];
        Permutation = [1:3;1:3;1:3];
        eta = [2,2,2];
        d = [1,1,1];
    case 3.11 %  geneMarkov by Gyoda
        times = 1; 
        gcd = 2;
        B = [0, 2,-2;
            -2, 0, 2;
             2,-2, 0]./gcd;
        R = ones(1,3).*gcd;
        syms k1 k2 k3
        Z = [k1;
             k2;
             k3];
        Mutation = [1;2;3];
        Permutation = [1:3;1:3;1:3];
        eta = [2,2,2].*times;
        d = [1,1,1].*times;
    case 3.2 % VarMarkov
        gcd = [1,1,1];
%         gcd = [2,1,1];

        B = [0,1,-1; -4,0,2; 4,-2,0]./gcd;
        R = [1,1,1].*gcd;
        Z = ones([size(R,2), max(R)+1]);
        Mutation = [1;2;3];
        Permutation = [1:3; 1:3; 1:3];
        eta = [2,4,4];
        d = [1,2,2];
    case 3.4 %BC_1 Kaufman
        gcd = [1,1,1];
        % gcd = [2,1,1];
        B = ([0,1,-1; -4,0,2; 4,-2,0]./gcd)';
        R = [1,1,1].*gcd;
        Z = ones([size(R,2), max(R)+1]);
        Mutation = [1;2;3];
        Permutation = [1:3; 1:3; 1:3];
        eta = [4,2,2].*times;
        d = [2,1,1].*times;    
    case 3.5 % Gyoda Problem 5.2
        B = [0, 1,-1;
            -1, 0, 2;
             1,-2, 0];
        R = [4,1,1];
         Z = ones([size(R,2), max(R)+1]);
        syms k1 k2 k3
        Z = [1, k1,k2,k1,1;
              1, 1, 1, 1, 1;
              1, 1, 1, 1, 1];
        Mutation = [1;2;3];
        Permutation = [1:3; 1:3; 1:3];
        eta = [2,4,4];
        d = [1,2,2];
%         eta = [2,2,2];
%         d = [0,1,0];
    case 3.6 % WRONG CASE since $\mu1 B \ne \pm B$
        times = 1; 
        gcd = 2;
        B = [0, 2,-2;
            -2, 0, 2;
             2,-2, 0]./gcd;
        R = ones(1,3);
        Z = ones([size(R,2), max(R)+1]);

        Mutation = [1;2;3];
        Permutation = [1:3;1:3;1:3];
        eta = [2,2,2];
        d = [1,1,1];
    case 3.9 % not gene CA
        B = [0, 1,-1;
            -1, 0, 2;
             1,-1, 0];
        R = [1,1,1];
        Z = [2,5;
             1,1;
             1,1];
        Mutation = [1;2];
        Permutation = [2,1,3;1:3];
        eta = [2,2,2];
        d = [1,1,1];
    case 3.67 % for eta and d
        times = 1; 
        gcd = 2;
        B = [0, 2,-2;
            -1, 0, 2;
             3, 0, 0;
             1,-2, 0];
        R = ones(1,4);
        Z = ones(4,2);
        Mutation = [1];
        Permutation = [2,3,1,4];
        eta = [2,4,2,5].*times;
        d = [1,1,1,1].*times;
   case 4 % B_4^1
        times = 1;
        gcd = 1;
        B = [0,-1, 0,-1;
             1, 0,-1, 0;
             0, 1, 0,-1;
             1, 0, 1, 0]./gcd;
        R = ones(1,4).*gcd;
        Z = ones([size(R,2), max(R)+1]);

        Mutation = [1];
        Permutation = [2,3,4,1];
        eta = [2,1,1,2].*times;
        d = [1,1,1,1].*times;
    case 4.2 % Somos4
        B = [0,-1,2,-1;
             1,0,-3,2;
            -2,3,0,-1;
             1,-2,1,0];
        R = [1,1,1,1];
        syms alpha beta
        Z = [alpha, beta;
              1,     1;
              1,     1;
              1,     1];
        
        Mutation = 1;
        Permutation = [2,3,4,1]; % sigma(i)就是i被置换后的数据。
        eta = [2,3,3,2];
        d = [1,1,1,1];

        % Mutation = [1;1];
        % Permutation = [2,3,4,1;1,4,3,2]; % sigma(i)就是i被置换后的数据。
        % eta = [2,3,3,2].*times;
        % d = [1,1,1,1].*times;
    case 4.22 % Somos4
        B = [0,-1,2,-1;
             1,0,-3,2;
            -2,3,0,-1;
             1,-2,1,0];
        R = [1,1,1,1];
        syms a b 
        Z = [1, 1;
             1, 1;
             1, 1;
             1, 1];     
        Mutation = 1;
        Permutation = [2,3,4,1]; 
        eta = [2,3,3,2];
        d = [1,1,1,1];
    case 5.0 % Lampe
        B = [0,-2,1,1;
             2,0,-1,-1;
             -1,-1,0,1;
             -1,1,-1,0];
        R = ones(1,4);
        Z = ones([size(R,2), max(R)-1]);
        Mutation = [1;4];
        Permutation = [2,1,3,4;2,3,4,1];
        eta = [2,2,2,2].*times;
        d = [1,1,1,1].*times;
    case 5.2 % Somos5
        B = [0,-1,1,1,-1;
              1,0,-2,0,1;
             -1,2,0,-2,1;
             -1,0,2,0,-1;
             1,-1,-1,1,0];
        R = ones(1,5);
        % Z = ones([size(R,2), max(R)+1]);
        syms alpha beta
        Z = [%alpha, beta;
              3,     5;
              1,     1;
              1,     1;
              1,     1;
              1,     1];
        Mutation = 1;
        Permutation = [2,3,4,5,1];
        eta = [2,3,4,3,2];
        d = [1,1,1,1,1];
    case 5.22 % Somos5
        B = [0,-1,1,1,-1;
              1,0,-2,0,1;
             -1,2,0,-2,1;
             -1,0,2,0,-1;
             1,-1,-1,1,0];
        R = ones(1,5);
        % Z = ones([size(R,2), max(R)+1]);
        syms alpha beta
        Z = [%alpha, beta;
              1,     1;
              1,     1;
              1,     1;
              1,     1;
              1,     1];
        Mutation = 1;
        Permutation = [1,5,4,3,2];
        eta = [2,2,2,2,2];
        d = [1,1,1,1,1];
    case 5.23 % Somos5
        B = [0,-1,1,1,-1;
              1,0,-2,0,1;
              1,2,0,-2,1;
              1,0,2,0,-1;
              1,-1,-1,1,0];
        R = ones(1,5);
        % Z = ones([size(R,2), max(R)+1]);
        syms alpha beta
        Z = [%alpha, beta;
              3,     5;
              1,     1;
              1,     1;
              1,     1;
              1,     1];
        Mutation = 1;
        Permutation = [1,3,4,5,2];
        eta = [2,2,2,2,2];
        d = [1,1,1,1,1];
    case 6.2 % Somos6
        B = [0,1,0,-2,0,1;
            -1,0,1,2,-2,0;
            0,-1,0,1,2,-2;
            2,-2,-1,0,1,0;
            0,2,-2,-1,0,1;
            -1,0,2,0,-1,0];
        R = ones(1,6);
        Z = ones([size(R,2), max(R)+1]);
        Mutation = 1;
        Permutation = [2,3,4,5,6,1];
        eta = [2,3,3,3,3,2].*times;
        d = [1,1,1,1,1,1].*times;
    otherwise
        sprintf('OOOPS, WARONG NUMBER! No such example!')
end
       
FindTheLaurentPolyOf(B,R,Z,Mutation,Permutation,eta,d)