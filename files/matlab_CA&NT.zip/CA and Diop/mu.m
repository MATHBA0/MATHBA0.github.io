function muB = mu(B,R,seq)
    [m, n] = size(B);
    muB = B;
    
    for t = 1:1:size(seq,2)
        k = seq(t);
        for i = 1:1:m
            for j = 1:1:n
                if or(i==k, j==k)
                    muB(i,j) = -B(i,j);
                else
                    muB(i,j) = B(i,j) + R(k)*(abs(B(i,k))*B(k,j) + B(i,k)*abs(B(k,j)))/2;
                end
            end
        end
        B = muB;
    end
end