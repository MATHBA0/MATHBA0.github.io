
n = size(B,1);
Perm_n = perms(1:n);

for s = 1:1:n
    muB = mu(B, R, s);
    
    for j = 1:1:size(Perm_n, 1)
        sigma = Perm_n(j, :);
        sigmuB = muB(sigma, sigma);
        if or(isequal(B,sigmuB), isequal(B, -sigmuB))
            disp([num2str(s), '  ', mat2str(sigma)])
        end
    end
end