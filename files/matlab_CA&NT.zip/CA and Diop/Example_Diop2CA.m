example = 4.25;

switch example
    case 0 %constans
        n = 2;
        x = sym('x_', [1,n]);
        T = 2;
        d = zeros(1,n);
    case 2.1 %Hyeperbola
        n = 2;
        x = sym('x_', [1,n]);
        T = x(1)^2 - x(1)*x(2) + x(2)^2;
        d = zeros(1,n);
    case 2.2 % Vieta
        n = 2;
        x = sym('x_', [1,n]);
        syms a b c;
        Tpower = [2,0;
                  1,1;
                  0,2;
                  0,0];
        Tcoeff = [a, b, 1, a];
        T = Tcoeff * prod(x.^Tpower,2);
        d = zeros(1,n);
    case 3.1 %Makrov
        n = 3;
        x = sym('x_', [1,n]);
        Tpower = [2,0,0; 0,2,0; 0,0,2; 1,1,1];
        Tcoeff = [1,1,1,-3];
        T = Tcoeff * prod(x.^Tpower,2);
        d = zeros(1,n);
    case 3.2 %geneMarkov
        n = 3;
        syms k1 k2 k3 k4;
        x = sym('x_', [1,n]);
        Tpower = [2,0,0; 0,2,0; 0,0,2; 1,1,0; 0,1,1;1,0,1;1,1,1];
        Tcoeff = [1,1,1,k3,k1,k2, k4];
        T = Tcoeff * prod(x.^Tpower,2);
        d = zeros(1,n);
    case 3.3 %varMarkov
        n = 3;
        syms k;
        x = sym('x_', [1,n]);
        T = prod(x.^[2,0,0]) + prod(x.^[0,4,0]) + prod(x.^[0,0,4])+ ...
            2*prod(x.^[1,2,0])+ 2*prod(x.^[1,0,2])+k*prod(x.^[0,2,2])-(7+k)* prod(x.^[1,2,2]);
        d = zeros(1,n);
    case 3.4 %Kaufman
        n = 3;
        x = sym('x_', [1,n]);
        Tpower = [4,0,0;
                  0,2,0;
                  0,1,1;
                  0,0,2;
                  2,1,1];
        Tcoeff = [1,1,2,1,-5];
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    case 4.2 %somos4
        n = 4;
        x = sym('x_', [1,n]);
        syms alpha beta
        Tpower = [2,0,0,2;
                  1,0,3,0;
                  0,3,0,1;
                  0,2,2,0;
                  1,1,1,1];
%         Tcoeff = [1,alpha,alpha,beta,-4];
        Tcoeff = [1,1,1,1,-4];
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    case 4.24 
        n = 4;
        x = sym('x_', [1,n]);
        syms a b c
        Tpower = [2,0,0,2;
                  1,0,3,0;
                  0,3,0,1;
                  0,2,2,0;
                  1,1,1,1];
        Tcoeff = [1,1,1,1,c];     
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    case 4.25 %
        n = 4;
        x = sym('x_', [1,n]);
        syms a b c
        Tpower = [2,0,0,1;
                  0,2,0,1;
                  0,1,2,0];
        Tcoeff = [1,b,a];     
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    case 4.26 % eg 5.2
        n = 4;
        x = sym('x_', [1,n]);
        syms a b c
        Tpower = [1,2,0,0;
                  2,1,0,0;
                  1,0,2,0;
                  1,0,0,2;
                  0,1,2,0;
                  2,0,0,1;
                  0,1,0,2;
                  0,2,0,1;
                  0,0,2,1];
        Tcoeff = [1,1,a,b^2,a,b,b^2,b,a*b];
%         Tcoeff = [1,1,1,1,1,1,1,1,1];
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    case 4.21 %somos4*x(1)x(2)
        n = 4;
        x = sym('x_', [1,n]);
        Tpower = [2,0,0,2;
                  1,0,3,0;
                  0,3,0,1;
                  0,2,2,0;
                  1,1,1,1];
        Tcoeff = [1,1,1,1,-4];  
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    case 4.22 %somos4 but x=(x1,x2,x3,x4,x5),x5 is trivial.
        n = 5;
        x = sym('x_', [1,n]);
        Tpower = [2,0,0,2,0;
                  1,0,3,0,0;
                  0,3,0,1,0;
                  0,2,2,0,0;
                  1,1,1,1,0];
        Tcoeff = [1,1,1,1,-4];      
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    case 4.23  % Somos4 reducive
        n = 2;
        x = sym('x_', [1,n]);
        Tpower = [2,2;
                  1,0;
                  0,1;
                  0,0;
                  1,1];
        Tcoeff = [1,1,1,1,-4];
        T = Tcoeff * prod(x.^Tpower,2);
        d = zeros(1,n);
    case 5.0 %Lampe
        n = 5;
        x = sym('x_', [1,n]);
        Tpower = [1,1,2,0,0;
                  1,1,0,2,0;
                  1,1,0,0,2;
                  2,0,1,0,1;
                  2,0,0,1,1;
                  0,2,1,0,1;
                  0,2,0,1,1;
                  0,0,2,1,1;
                  0,0,1,2,1;
                  1,1,1,1,1];
        Tcoeff = [1,1,1,1,1,1,1,1,1,-9];
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    case 5.2 %somos5
        n = 5;
        x = sym('x_', [1,n]);
        syms alpha beta
        Tpower = [2,0,0,2,1;
                  1,2,0,0,2;
                  1,0,2,2,0;
                  0,2,2,0,1;
                  0,1,3,1,0;
                  1,1,1,1,1];
        Tcoeff = [1,1,alpha,alpha,beta,0];
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
     case 6.2 %somos6
        n = 6;
        x = sym('x_', [1,n]);
        Tpower = [2,1,0,0,1,2;
                  2,0,0,1,3,0;
                  0,3,1,0,0,2;
                  1,0,2,1,2,0;
                  0,2,1,2,0,1;
                  1,0,1,3,1,0;
                  0,1,3,1,0,1;
                  0,0,3,3,0,0;
                  1,1,1,1,1,1];
        Tcoeff = [1,1,1,1,1,1,1,1,-8];
        T = Tcoeff*prod(x.^Tpower,2);
        d = zeros(1,n);
    otherwise
        sprintf('OOOPS, WARONG NUMBER! No such example!')
end


M = FindTheClusterSymPairOf(T,d,x);

%sym2latex(['$',sym2str(sum(x)),'$']);
